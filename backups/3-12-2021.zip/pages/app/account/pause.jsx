export default function AccountPause() {
    return (
        <div>
            
        </div>
    )
}
