export default function AccountDelete() {
    return (
        <div>
            
        </div>
    )
}
