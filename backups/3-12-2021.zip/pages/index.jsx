export default function Home() {

  return (
    <h1>Babillio oue</h1>
  )
}
