export default function Loader() {
    return (
        <div className="large-loader">
            <img src="/images/loading.svg" alt="loading..." />
        </div>
    )
}
