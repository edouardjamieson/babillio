export default function LoaderSmall() {
    return (
        <div className="small-loader">
            <img src="/images/loading.svg" alt="loading..." />
        </div>
    )
}
